import json
import sys
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))

from semantic_zoom import (  # noqa: E402
    build_hierarchy,
    build_vega_spec,
    cached_word_counts,
    chronological_runs,
    render_html,
    validate_sources,
)


def sample_projection():
    clusters = [0, 0, 0, 1, 1, -1]
    return {
        "points": [
            {
                "revision_index": index,
                "revision_id": str(100 + index),
                "timestamp": f"2020-01-0{index + 1}T00:00:00Z",
                "author": "Editor",
                "clean_word_count": 100 + index,
                "mds": [index / 10, (index % 2) / 10],
                "cluster_id": cluster,
                "semantic_jump_from_previous": 0 if index == 0 else index / 100,
            }
            for index, cluster in enumerate(clusters)
        ]
    }


def sample_keywords():
    return {
        "revision_pairs": [
            {
                "previous_revision_id": str(100 + index),
                "current_revision_id": str(101 + index),
                "focus_keywords": [f"Topic {index}", "Security Council", "policy", "history", "vote"],
                "added_keywords": ["new claim"],
                "removed_keywords": ["old claim"],
            }
            for index in range(5)
        ]
    }


def test_validate_sources_detects_alignment_error():
    projection = sample_projection()
    keywords = sample_keywords()
    keywords["revision_pairs"][2]["current_revision_id"] = "wrong"
    try:
        validate_sources(projection, keywords)
    except ValueError as error:
        assert "passt nicht" in str(error)
    else:
        raise AssertionError("Fehlende Paarvalidierung")


def test_runs_and_four_level_hierarchy():
    projection = sample_projection()
    hierarchy = build_hierarchy(
        projection,
        sample_keywords(),
        word_counts=[(3, 1), (2, 4), (7, 0), (1, 2), (5, 5)],
        root_label="Example",
    )
    assert chronological_runs(projection["points"]) == [
        {"cluster_id": 0, "start": 0, "end": 3},
        {"cluster_id": 1, "start": 3, "end": 5},
        {"cluster_id": -1, "start": 5, "end": 6},
    ]
    assert len(hierarchy["clusters"]) == 2
    assert len(hierarchy["sections"]) == 1
    assert len(hierarchy["edges"]) == 5
    assert hierarchy["roots"][0]["label"] == "Example"
    assert hierarchy["clusters"][0]["parent_id"] == "root"
    assert hierarchy["edges"][0]["count_text"] == "+3/−1 Wörter"
    assert "Wörter" not in hierarchy["edges"][0]["label"]
    assert hierarchy["edges"][0]["parent_id"].startswith("section-")
    assert hierarchy["edges"][-1]["parent_id"] == "root"


def test_vega_spec_uses_semantic_zoom_and_cartographic_label_transform():
    projection = sample_projection()
    hierarchy = build_hierarchy(projection, sample_keywords())
    spec = build_vega_spec("Example", projection, hierarchy)
    assert any(signal["name"] == "zoomLevel" for signal in spec["signals"])
    assert any(signal["name"] == "rootOpacity" for signal in spec["signals"])
    assert any(signal["name"] == "zooming" for signal in spec["signals"])
    assert spec["autosize"] == "none"
    trajectory = next(mark for mark in spec["marks"] if mark.get("name") == "trajectory")
    assert trajectory["type"] == "rule"
    assert len(next(data for data in spec["data"] if data["name"] == "edges")["values"]) == 5
    root_data = next(data for data in spec["data"] if data["name"] == "rootNode")
    assert root_data["values"][0]["label"] == "Article"
    visible = next(data for data in spec["data"] if data["name"] == "visibleParentLabels")
    assert visible["transform"][0]["expr"] == "!zooming && !down"
    text_mark = next(mark for mark in spec["marks"] if mark.get("name") == "semanticLabels")
    label_transform = next(item for item in text_mark["transform"] if item["type"] == "label")
    assert label_transform["avoidBaseMark"] is False
    assert label_transform["anchor"] == ["top"]
    assert text_mark["from"]["data"] == "semanticLabelAnchors"
    edge_text = next(mark for mark in spec["marks"] if mark.get("name") == "edgeLabels")
    assert edge_text["from"]["data"] == "visibleEdgeLabels"
    assert edge_text["encode"]["enter"]["align"]["value"] == "center"
    assert edge_text["encode"]["enter"]["baseline"]["value"] == "middle"
    assert not any(mark.get("name") in {"rootCenterMark", "clusterCenterMarks"} for mark in spec["marks"])
    assert "+3/−1 Wörter" not in json.dumps(spec, ensure_ascii=False)
    assert "Level 1" not in json.dumps(spec)
    assert "dblclick" in json.dumps(spec)


def test_html_has_no_interactive_model_call():
    projection = sample_projection()
    hierarchy = build_hierarchy(projection, sample_keywords())
    page = render_html("Example", build_vega_spec("Example", projection, hierarchy))
    assert "fetch(" not in page
    assert "OpenAI" not in page
    assert "vega.parse(spec)" in page
    assert "ResizeObserver" in page
    assert '<span id="zoom-status">Zoom 1.0×</span>' in page


def test_cached_git_counts_are_reused(tmp_path):
    projection_path = (tmp_path / "projection.json").resolve()
    keywords_path = (tmp_path / "keywords.json").resolve()
    labels_path = tmp_path / "labels.json"
    labels_path.write_text(json.dumps({
        "projection": str(projection_path),
        "revision_keywords": str(keywords_path),
        "word_counts_are_git_word_diff": True,
        "hierarchy": {"edges": [
            {"count_text": "+3/−1 Wörter"},
            {"count_text": "+0/−8 Wörter"},
        ]},
    }), encoding="utf-8")
    assert cached_word_counts(
        labels_path, projection_path, keywords_path, 2
    ) == [(3, 1), (0, 8)]
