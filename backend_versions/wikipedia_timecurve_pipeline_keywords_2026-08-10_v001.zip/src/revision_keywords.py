#!/usr/bin/env python3
"""Extract grounded keywords from consecutive Wikipedia revisions."""

import argparse
import difflib
import json
import os
import xml.etree.ElementTree as ET
from dataclasses import asdict, dataclass
from pathlib import Path

from openai import OpenAI
from pydantic import BaseModel, Field

from config import BASE_DIR, article_paths, article_slug
from output_utils import next_numbered_path
from text_cleaning import clean_wikitext, extract_infobox_text


# Change only this line to use another OpenAI model.
MODEL = "gpt-5.6-terra"

SYSTEM_PROMPT = """Only use concepts explicitly supported by this revision.
Never use outside knowledge."""

DEFAULT_LIMIT = 0 # Sonderwert, keine Begrenzung
DEFAULT_MAX_DIFF_CHARS = 20_000
MIN_MAX_DIFF_CHARS = len("[DIFF TRUNCATED]")


class RevisionKeywords(BaseModel):
    added_keywords: list[str] = Field(max_length=8)
    removed_keywords: list[str] = Field(max_length=8)
    focus_keywords: list[str] = Field(min_length=5, max_length=5)


@dataclass(frozen=True)
class DiffPassage:
    """One added or removed passage belonging to a change unit."""

    change_type: str
    change_number: int
    words: list[str]
    start: int
    end: int


@dataclass(frozen=True)
class DiffResult:
    """Rendered diff plus an auditable account of any prompt truncation."""

    text: str
    diff_truncated: bool
    diff_original_chars: int
    diff_included_chars: int
    total_change_units: int
    included_change_units: int
    omitted_change_units: int
    shortened_change_units: int

    def metadata(self) -> dict:
        data = asdict(self)
        data.pop("text")
        return data


def load_api_key(env_path: Path) -> str:
    """Read OPENAI_API_KEY from the environment or the project's .env file."""
    api_key = os.environ.get("OPENAI_API_KEY", "").strip()
    if api_key:
        return api_key

    if env_path.exists():
        for line in env_path.read_text(encoding="utf-8").splitlines():
            name, separator, value = line.partition("=")
            if separator and name.strip() == "OPENAI_API_KEY":
                api_key = value.strip().strip('"\'')
                if api_key:
                    return api_key

    raise RuntimeError(
        "OPENAI_API_KEY fehlt. Bitte den Schlüssel in .env eintragen."
    )


def local_name(tag: str) -> str:
    """Return an XML tag without its optional namespace."""
    return tag.rsplit("}", 1)[-1]


def child_text(element: ET.Element, name: str) -> str:
    for child in element:
        if local_name(child.tag) == name:
            return child.text or ""
    return ""


def iter_revisions(
    xml_path: Path,
    min_revision_chars: int = 0,
    revision_ids: list[str] | None = None,
):
    """Yield requested cleaned revisions without cleaning unused XML entries."""
    if not xml_path.exists():
        raise FileNotFoundError(f"XML nicht gefunden: {xml_path}")
    if xml_path.stat().st_size == 0:
        raise ValueError(f"XML-Datei ist leer: {xml_path}")

    wanted_ids = set(revision_ids) if revision_ids is not None else None
    for _, element in ET.iterparse(xml_path, events=("end",)):
        if local_name(element.tag) != "revision": # alles überspringen, was keine Revision ist
            continue

        revision_id = child_text(element, "id")
        if wanted_ids is not None and revision_id not in wanted_ids:
            element.clear()
            continue

        raw_text = child_text(element, "text")
        article_text = clean_wikitext(raw_text)
        infobox_text = extract_infobox_text(raw_text)
        revision = {
            "revision_id": revision_id,
            "timestamp": child_text(element, "timestamp"),
            "text": " ".join(
                part for part in (article_text, infobox_text) if part
            ),
        }
        element.clear()

        if len(revision["text"]) >= min_revision_chars:
            yield revision


def resolve_projection_path(visualization_path: Path) -> Path:
    """Accept either a visualization HTML or its projection JSON sidecar."""
    visualization_path = visualization_path.expanduser().resolve()
    if visualization_path.suffix.casefold() == ".html":
        visualization_path = visualization_path.with_name(
            f"{visualization_path.stem}_projection.json"
        )
    if not visualization_path.exists():
        raise FileNotFoundError(
            f"Projektionsdatei der Visualisierung nicht gefunden: {visualization_path}"
        )
    return visualization_path


def find_latest_visualization(article: str) -> Path:
    """Return the highest-numbered complete visualization for an article."""
    paths = article_paths(article)
    output_dir = Path(paths["output_dir"])
    prefix = paths["output_basename"] + "_"
    candidates = []

    for html_path in output_dir.glob(f"{prefix}*.html"):
        number = html_path.stem.removeprefix(prefix)
        projection = html_path.with_name(f"{html_path.stem}_projection.json")
        if number.isdigit() and projection.exists():
            candidates.append((int(number), html_path))

    if not candidates:
        raise FileNotFoundError(
            f"Keine vollständige Visualisierung gefunden: {output_dir}"
        )
    return max(candidates, key=lambda item: item[0])[1]


def load_visualization_revision_ids(projection_path: Path) -> list[str]:
    """Read the exact ordered point IDs used by the selected visualization."""
    data = json.loads(projection_path.read_text(encoding="utf-8"))
    points = data.get("points")
    if not isinstance(points, list):
        raise ValueError("Die Projektionsdatei enthält keine gültige points-Liste.")

    if any(not isinstance(point, dict) for point in points):
        raise ValueError("Die points-Liste enthält einen ungültigen Eintrag.")
    revision_ids = [str(point.get("revision_id", "")) for point in points]
    if len(revision_ids) < 2 or any(not revision_id for revision_id in revision_ids):
        raise ValueError(
            "Die Visualisierung muss mindestens zwei Punkte mit revision_id enthalten."
        )
    if len(set(revision_ids)) != len(revision_ids):
        raise ValueError("Die Visualisierung enthält doppelte Revisions-IDs.")
    return revision_ids


def select_visualized_revisions(revisions, revision_ids: list[str]):
    """Yield XML revisions in exactly the order stored by the visualization."""
    wanted_index = 0
    for revision in revisions:
        if revision["revision_id"] != revision_ids[wanted_index]:
            continue
        yield revision
        wanted_index += 1
        if wanted_index == len(revision_ids):
            return

    missing = revision_ids[wanted_index:]
    raise ValueError(
        "Revisions-IDs der Visualisierung fehlen in der XML-Datei: "
        + ", ".join(missing[:5])
    )


def marked_window(
    words: list[str],
    start: int,
    end: int,
    context: int = 12,
    max_changed_words: int | None = None,
) -> str:
    """Show changed words with context and optionally shorten the change."""
    left = words[max(0, start - context):start]
    changed = words[start:end]
    right = words[end:min(len(words), end + context)]

    if max_changed_words is None or len(changed) <= max_changed_words:
        marked_change = ["[["] + changed + ["]]"]
    elif max_changed_words < 1:
        raise ValueError("max_changed_words muss positiv sein.")
    else:
        head_count = (max_changed_words + 1) // 2
        tail_count = max_changed_words // 2
        omitted = len(changed) - max_changed_words
        marked_change = ["[["] + changed[:head_count] + ["]]"]
        marked_change.append(f"[... {omitted} changed words omitted ...]")
        if tail_count:
            marked_change.extend(
                ["[["] + changed[len(changed) - tail_count:] + ["]]"]
            )

    return " ".join(left + marked_change + right)


def render_passage(
    passage: DiffPassage, max_changed_words: int | None = None
) -> str:
    display = marked_window(
        passage.words,
        passage.start,
        passage.end,
        max_changed_words=max_changed_words,
    )
    return f"{passage.change_type} {passage.change_number}: {display}"


def render_unit(
    unit: list[DiffPassage], max_changed_words: int | None = None
) -> list[str]:
    return [render_passage(passage, max_changed_words) for passage in unit]


def truncation_marker(
    total_units: int, omitted_units: int, shortened_units: int = 0
) -> str:
    details = [
        f"{omitted_units} of {total_units} change units omitted",
    ]
    if shortened_units:
        details.append(f"{shortened_units} change unit shortened")
    return "[DIFF TRUNCATED: " + "; ".join(details) + "]"


def render_truncated_diff(lines: list[str], marker: str) -> str:
    if not lines:
        return marker
    return "\n".join(lines + ["", marker])


def compact_first_unit(
    unit: list[DiffPassage], marker: str, max_chars: int
) -> list[str]:
    """Fit a word-safe view of an oversized first unit into the prompt."""
    maximum_changed_words = max(passage.end - passage.start for passage in unit)
    low = 1
    high = maximum_changed_words
    best_lines = []

    while low <= high:
        candidate_limit = (low + high) // 2
        candidate_lines = render_unit(unit, candidate_limit)
        candidate_text = render_truncated_diff(candidate_lines, marker)
        if len(candidate_text) <= max_chars:
            best_lines = candidate_lines
            low = candidate_limit + 1
        else:
            high = candidate_limit - 1

    return best_lines


def build_diff(previous_text: str, current_text: str,
               max_chars: int = DEFAULT_MAX_DIFF_CHARS) -> DiffResult:
    """Build a bounded, prefix-faithful diff with truncation metadata."""
    if max_chars < MIN_MAX_DIFF_CHARS:
        raise ValueError(
            f"max_chars muss mindestens {MIN_MAX_DIFF_CHARS} betragen, "
            "damit ein Kürzungsmarker Platz hat."
        )

    previous_words = previous_text.split()
    current_words = current_text.split()
    matcher = difflib.SequenceMatcher(None, previous_words, current_words)

    units = []
    for change_number, (tag, i1, i2, j1, j2) in enumerate(
        (opcode for opcode in matcher.get_opcodes() if opcode[0] != "equal"),
        start=1,
    ):
        unit = []
        if tag in {"delete", "replace"}:
            unit.append(DiffPassage(
                "REMOVED", change_number, previous_words, i1, i2
            ))
        if tag in {"insert", "replace"}:
            unit.append(DiffPassage(
                "ADDED", change_number, current_words, j1, j2
            ))
        units.append(unit)

    rendered_units = [render_unit(unit) for unit in units]
    full_text = "\n".join(
        line for rendered_unit in rendered_units for line in rendered_unit
    )
    total_units = len(units)
    original_chars = len(full_text)

    if original_chars <= max_chars:
        return DiffResult(
            text=full_text,
            diff_truncated=False,
            diff_original_chars=original_chars,
            diff_included_chars=original_chars,
            total_change_units=total_units,
            included_change_units=total_units,
            omitted_change_units=0,
            shortened_change_units=0,
        )

    selected_lines = []
    included_units = 0
    for rendered_unit in rendered_units:
        candidate_included = included_units + 1
        candidate_omitted = total_units - candidate_included
        marker = truncation_marker(total_units, candidate_omitted)
        candidate_text = render_truncated_diff(
            selected_lines + rendered_unit, marker
        )
        if len(candidate_text) > max_chars:
            break
        selected_lines.extend(rendered_unit)
        included_units = candidate_included

    shortened_units = 0
    if included_units == 0 and units:
        omitted_units = total_units - 1
        marker = truncation_marker(total_units, omitted_units, shortened_units=1)
        selected_lines = compact_first_unit(units[0], marker, max_chars)
        if selected_lines:
            included_units = 1
            shortened_units = 1

    omitted_units = total_units - included_units
    marker = truncation_marker(total_units, omitted_units, shortened_units)
    if len(marker) > max_chars:
        marker = "[DIFF TRUNCATED]"
    text = render_truncated_diff(selected_lines, marker)

    return DiffResult(
        text=text,
        diff_truncated=True,
        diff_original_chars=original_chars,
        diff_included_chars=len(text),
        total_change_units=total_units,
        included_change_units=included_units,
        omitted_change_units=omitted_units,
        shortened_change_units=shortened_units,
    )


def build_user_prompt(diff_text: str) -> str:
    return f"""Compare these consecutive Wikipedia revisions.
The supplied diff may be truncated. Use only the visible passages and never
assume that they represent every change in the revision.
If ADDED passages exist, return 1 to 8 added keywords; otherwise return an empty list.
If REMOVED passages exist, return 1 to 8 removed keywords; otherwise return an empty list.
Never fill one list only because the other list contains keywords.
Each list must contain either zero keywords or 1 to 8 keywords.
Each keyword must contain one, two, three, or four words.
For added and removed keywords, use only concepts inside [[ double brackets ]].

For ADDED keywords, select concepts representing the important information
introduced by the added passage.

For REMOVED keywords, select concepts representing the important information
contained in the removed passage.

Treat ADDED and REMOVED independently.

Return exactly 5 focus keywords describing the specific content changed in this revision.
Determine the focus from the words inside [[ double brackets ]] and their immediate context.
Do not summarize the whole article.
Do not choose a section heading or the article's general topic unless the changed text itself supports it.
Prefer specific people, places, events, policies, claims, or institutions affected by the change.
Only describe a change as controversial or polarizing when the changed text explicitly supports that.

REVISION DIFF
{diff_text}"""


def request_keywords(
    client: OpenAI, model: str, diff_text: str
) -> dict:
    """Ask for added, removed, and change-focused keywords."""
    diff_lines = diff_text.splitlines()
    if not any(
        line.startswith(("ADDED ", "REMOVED ")) for line in diff_lines
    ):
        return {
            "added_keywords": [],
            "removed_keywords": [],
            "focus_keywords": [],
        }

    change_types = {
        "added_keywords": "ADDED ",
        "removed_keywords": "REMOVED ",
    }
    prompt = build_user_prompt(diff_text)

    for attempt in range(3):
        response = client.responses.parse(
            model=model,
            store=False,
            input=[
                {"role": "system", "content": SYSTEM_PROMPT},
                {"role": "user", "content": prompt},
            ],
            text_format=RevisionKeywords,
        )
        if response.output_parsed is None:
            raise RuntimeError(
                f"Keine auswertbare Modellantwort: {response.output_text}"
            )

        keywords = response.output_parsed.model_dump()
        keywords["focus_keywords"] = [
            " ".join(keyword.split()[:4])
            for keyword in keywords["focus_keywords"]
        ]
        invalid_types = []
        for name, prefix in change_types.items():
            if not any(line.startswith(prefix) for line in diff_lines):
                keywords[name] = []
                continue

            keywords[name] = [
                " ".join(keyword.split()[:4]) for keyword in keywords[name]
            ]
            if len(keywords[name]) < 1:
                invalid_types.append(prefix.strip())

        if not invalid_types:
            return keywords
        prompt += (
            "\nCorrection required: Return 1 to 8 grounded keywords for "
            + " and ".join(invalid_types)
            + "."
        )

    raise RuntimeError(
        "Das Modell lieferte trotz Wiederholung kein Stichwort."
    )


def analyze(xml_path: Path, revision_ids: list[str], client: OpenAI, model: str,
            limit: int, max_diff_chars: int) -> list[dict]:
    revisions = iter(select_visualized_revisions(
        iter_revisions(xml_path, revision_ids=revision_ids), revision_ids
    ))
    try:
        previous = next(revisions)
    except StopIteration as exc:
        raise ValueError("Die XML-Datei enthält keine geeignete Revision.") from exc

    results = []
    for pair_number, current in enumerate(revisions, start=1):
        if limit > 0 and pair_number > limit:
            break

        print(
            f"[{pair_number}] Revision {previous['revision_id']} -> "
            f"{current['revision_id']}"
        )
        diff_result = build_diff(
            previous["text"], current["text"], max_chars=max_diff_chars
        )
        keywords = request_keywords(client, model, diff_result.text)
        results.append({
            "previous_revision_id": previous["revision_id"],
            "previous_timestamp": previous["timestamp"],
            "current_revision_id": current["revision_id"],
            "current_timestamp": current["timestamp"],
            **diff_result.metadata(),
            **keywords,
        })
        previous = current

    return results


def print_results(results: list[dict]) -> None:
    print("\nERGEBNISSE")
    for result in results:
        print(
            f"\n{result['previous_revision_id']} -> "
            f"{result['current_revision_id']}"
        )
        if result["total_change_units"] == 0:
            print("  Keine Textänderung erkannt.")
        elif result["included_change_units"] == 0:
            print("  Keine Änderungspassage passte in das Diff-Limit.")
        if result["diff_truncated"]:
            print(
                "  DIFF GEKÜRZT: "
                f"{result['omitted_change_units']} Units ausgelassen, "
                f"{result['shortened_change_units']} gekürzt"
            )
        print("  ADDED:")
        for keyword in result["added_keywords"]:
            print(f"    {keyword}")
        print("  REMOVED:")
        for keyword in result["removed_keywords"]:
            print(f"    {keyword}")
        print("  MAIN FOCUS:")
        for keyword in result["focus_keywords"]:
            print(f"    {keyword}")


def parse_args():
    parser = argparse.ArgumentParser(
        description="Grounded keywords for changes between consecutive revisions."
    )
    source = parser.add_mutually_exclusive_group(required=True)
    source.add_argument("--article", help='Article name, e.g. "Palestine"')
    source.add_argument("--xml", type=Path, help="Direct path to a revision XML")
    parser.add_argument(
        "--visualization", type=Path,
        help="Optional visualization; otherwise use the latest article visualization",
    )
    parser.add_argument("--model", default=MODEL, help=f"OpenAI model (default: {MODEL})")
    parser.add_argument(
        "--limit", type=int, default=DEFAULT_LIMIT,
        help="Optional number of visualization pairs; 0 means all (default: all)",
    )
    parser.add_argument("--max-diff-chars", type=int, default=DEFAULT_MAX_DIFF_CHARS)
    parser.add_argument("--output", type=Path)
    return parser.parse_args()


def main() -> int:
    args = parse_args()
    if args.limit < 0:
        raise ValueError("--limit darf nicht negativ sein.")
    if args.max_diff_chars < MIN_MAX_DIFF_CHARS:
        raise ValueError(
            f"--max-diff-chars muss mindestens {MIN_MAX_DIFF_CHARS} betragen."
        )

    xml_path = (
        Path(article_paths(args.article)["xml_path"])
        if args.article else args.xml.expanduser().resolve()
    )
    if args.visualization:
        visualization_path = args.visualization
    elif args.article:
        visualization_path = find_latest_visualization(args.article)
    else:
        raise ValueError("Bei --xml muss --visualization angegeben werden.")

    projection_path = resolve_projection_path(visualization_path)
    revision_ids = load_visualization_revision_ids(projection_path)
    slug = article_slug(args.article) if args.article else xml_path.stem
    visualization_name = projection_path.stem.removesuffix("_projection")
    output_path = args.output or Path(next_numbered_path(
        str(projection_path.parent),
        f"{visualization_name}_revision_keywords_{article_slug(args.model)}",
        ext="json",
    ))

    print(f"XML: {xml_path}")
    print(f"Visualisierung: {projection_path}")
    print(f"Modell: {args.model}")
    print(f"Visualisierungspunkte: {len(revision_ids)}")
    print(f"Paare: {'alle' if args.limit == 0 else args.limit}")

    api_key = load_api_key(Path(BASE_DIR) / ".env")
    results = analyze(
        xml_path=xml_path,
        revision_ids=revision_ids,
        client=OpenAI(api_key=api_key),
        model=args.model,
        limit=args.limit,
        max_diff_chars=args.max_diff_chars,
    )
    print_results(results)

    payload = {
        "article": args.article or slug,
        "xml": str(xml_path),
        "visualization": str(projection_path),
        "model": args.model,
        "sampling": "exact_revision_order_from_visualization",
        "max_diff_chars": args.max_diff_chars,
        "truncated_revision_pair_count": sum(
            result["diff_truncated"] for result in results
        ),
        "system_prompt": SYSTEM_PROMPT,
        "revision_pairs": results,
    }
    output_path.parent.mkdir(parents=True, exist_ok=True)
    output_path.write_text(
        json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8"
    )
    print(f"\nJSON gespeichert: {output_path}")
    return 0


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except (FileNotFoundError, ValueError, RuntimeError, ET.ParseError) as error:
        print(f"[FEHLER] {error}")
        raise SystemExit(1) from error
