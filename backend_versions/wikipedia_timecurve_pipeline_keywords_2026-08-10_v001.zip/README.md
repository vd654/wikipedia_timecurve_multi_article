# Wikipedia Timecurve

Das Projekt erzeugt eine semantische Timecurve aus Wikipedia-Revisionen und
kann anschließend Added-, Removed- und Focus-Stichwörter für die dargestellten
Revisionspaare generieren.

## Installation

```bash
pip install -r requirements.txt
```

Für die Stichwortgenerierung wird der OpenAI-Schlüssel in `.env` gespeichert:

```text
OPENAI_API_KEY=sk-...
```

## Dateien

```text
src/
├── wiki_api.py           Revisionen herunterladen
├── main_pipeline.py      semantische MDS-Timecurve erzeugen
├── revert_detection.py   optionales, separates Revert-Modul
├── revision_keywords.py  Added-, Removed- und Focus-Stichwörter
├── text_cleaning.py      MediaWiki-Text bereinigen
├── config.py             gemeinsame Kommandozeilenoptionen
└── output_utils.py       nummerierte Ausgabedateien
```

## 1. Revisionen herunterladen

```bash
python src/wiki_api.py --article "Palestine"
```

Die XML-Datei landet automatisch unter `data/Palestine/Palestine.xml`.

## 2. Timecurve erzeugen

```bash
python src/main_pipeline.py --article "Palestine"
```

Die Pipeline ist bewusst kurz:

```text
XML
→ alle Revisionen im gewählten Zeitraum
→ temporäre Token-Chunks
→ ein gemittelter, L2-normalisierter Vektor pro Revision
→ eine Kosinus-Distanzmatrix
→ klassische MDS in 2D
→ HDBSCAN direkt auf der 2D-Projektion
→ chronologische Kurve mit Clusterfarben
```

Standardmäßig werden alle Revisionen im gewählten Zeitraum verwendet. Eine
gröbere Sampling-Dichte muss ausdrücklich gewählt werden:

```bash
python src/main_pipeline.py --article "Palestine" --sample-strategy weekly
python src/main_pipeline.py --article "Palestine" --sample-strategy monthly
```

Ein begrenzter Lauf mit allen Revisionen kann getrennt gespeichert werden:

```bash
python src/main_pipeline.py --article "Palestine" \
  --start 2012-12-02 --end 2014-07-23 \
  --sample-strategy all --output-name "Palestine_small"
```

Dieser Lauf verwendet weiterhin `data/Palestine/Palestine.xml`, schreibt seine
Dateien aber separat nach `output/Palestine_small/`.

Die Artikel müssen wegen der Modellgrenze in maximal 256 Tokens lange Chunks
geteilt werden. Diese Chunks sind nur technische Encoding-Einheiten. Sie werden
nicht zwischen Revisionen zugeordnet und unmittelbar zu genau einem
Revisionsvektor gemittelt. Abschnitte und Sätze sind keine Analyseeinheiten.

Die Distanz zweier Revisionen ist direkt:

```text
1 - dot(L2-normalisierter Revisionsvektor A,
        L2-normalisierter Revisionsvektor B)
```

Es gibt keine lexikalische zweite Matrix, keine Hybridgewichtung, keine
Perzentil-Streckung und kein UMAP. HDBSCAN wird erst nach MDS direkt auf den
beiden sichtbaren Koordinaten ausgeführt. Eine Clusteranzahl wird nicht
vorgegeben; HDBSCAN bestimmt sie aus der Punktdichte und kann Noise markieren.

### Projektionsqualität

Die Projektionsdatei und die HTML-Ausgabe zeigen:

- normalisierten Stress-1 zwischen Kosinus- und 2D-Distanzen,
- Shepard-Korrelation zwischen Kosinus- und 2D-Distanzen.

Damit lässt sich prüfen, wie gut sichtbare Sprünge die ursprüngliche
Distanzmatrix wiedergeben.

### Ausgabedateien

Jeder Lauf wird fortlaufend nummeriert und erzeugt nur vier Dateien:

```text
output/Palestine/Palestine_bert_timecurve_003.html
output/Palestine/Palestine_bert_timecurve_003_projection.json
output/Palestine/Palestine_bert_timecurve_003_revision_embeddings.npy
output/Palestine/Palestine_bert_timecurve_003_cosine_distance_matrix.npy
```

Die HTML-Datei unterstützt Zoom mit Mausrad beziehungsweise Trackpad und Pan
durch Ziehen.

## 3. Stichwörter erzeugen

```bash
python src/revision_keywords.py --article "Palestine"
```

Das Skript verwendet automatisch die neueste vollständige Visualisierung und
deren exakte Revisionsreihenfolge. Bei einer Weekly-Timecurve werden daher die
aufeinanderfolgenden Weekly-Punkte analysiert.

Die Ausgabe enthält:

- `added_keywords`: 1 bis 8 Stichwörter für hinzugefügte Inhalte,
- `removed_keywords`: 1 bis 8 Stichwörter für entfernte Inhalte,
- `focus_keywords`: 5 Stichwörter zum Schwerpunkt der konkreten Änderung,
- `diff_truncated`: Kennzeichnung, ob der Modell-Diff gekürzt wurde,
- `diff_original_chars` und `diff_included_chars`: Zeichenumfang vor und nach
  der Begrenzung; der zweite Wert umfasst auch den Kürzungsmarker,
- `total_change_units`, `included_change_units`, `omitted_change_units` und
  `shortened_change_units`: Umfang und Art der Kürzung.

Jedes Stichwort darf höchstens vier Wörter enthalten. `ADDED` und `REMOVED`
werden unabhängig behandelt. Wenn keine bereinigte Änderung vorhanden ist,
bleiben die Listen leer.

Modelldiffs sind standardmäßig auf 20.000 Zeichen begrenzt. Passt nicht der
gesamte Diff, werden nur zusammenhängende Änderungs-Units vom Anfang
aufgenommen; nach der ersten nicht mehr passenden Unit wird abgebrochen. Ein
expliziter `[DIFF TRUNCATED: ...]`-Marker informiert das Modell über
Auslassungen. Ist bereits die erste Unit zu groß, wird sie an Wortgrenzen
gekürzt und zeigt jeweils Anfang und Ende der geänderten Passage. Jede Kürzung
wird außerdem mit den oben genannten Feldern im JSON protokolliert. Auf
Dateiebene enthält `truncated_revision_pair_count` die Gesamtzahl betroffener
Revisionspaare. Das Limit lässt sich mit `--max-diff-chars` ändern.

Das Standardmodell steht am Anfang von `src/revision_keywords.py`:

```python
MODEL = "gpt-5.6-terra"
```

Der System-Prompt lautet:

```text
Only use concepts explicitly supported by this revision.
Never use outside knowledge.
```
