"""Detect exact article reverts and calculate Yasseri's M measure."""

from collections import Counter, defaultdict


def editor_pair(left: str, right: str) -> tuple[str, str]:
    """Return a stable key for an unordered editor pair."""
    return tuple(sorted((left, right)))


def detect_sha1_reverts(revisions: list[dict]) -> list[dict]:
    """Find revisions that restore an earlier SHA1-identical article state."""
    latest_state = {}
    events = []

    for index, revision in enumerate(revisions):
        sha1 = revision.get("sha1", "")
        target_index = latest_state.get(sha1) if sha1 else None

        # A direct duplicate contains no intervening edit and is not a revert.
        if target_index is not None and target_index < index - 1:
            previous = revisions[index - 1]
            reverter = revision["user"]
            reverted_editor = previous["user"]
            if reverter != reverted_editor:
                events.append({
                    "revision_index": index,
                    "revision_id": revision["revision_id"],
                    "timestamp": revision["timestamp"],
                    "reverter": reverter,
                    "reverted_editor": reverted_editor,
                    "reverted_revision_id": previous["revision_id"],
                    "restored_revision_id": revisions[target_index]["revision_id"],
                    "restored_revision_index": target_index,
                    "intervening_revision_count": index - target_index - 1,
                    "pair": list(editor_pair(reverter, reverted_editor)),
                })

        if sha1:
            latest_state[sha1] = index

    directions = defaultdict(set)
    for event in events:
        directions[tuple(event["pair"])].add(
            (event["reverter"], event["reverted_editor"])
        )
    mutual_pairs = {
        pair for pair, pair_directions in directions.items()
        if len(pair_directions) == 2
    }
    for event in events:
        event["mutual_in_full_history"] = tuple(event["pair"]) in mutual_pairs
    return events


def yasseri_m_measure(revisions: list[dict], events: list[dict]) -> dict:
    """Calculate M from mutual reverts, excluding the strongest editor pair."""
    edit_counts = Counter(revision["user"] for revision in revisions)
    directions = defaultdict(set)
    for event in events:
        pair = tuple(event["pair"])
        directions[pair].add((event["reverter"], event["reverted_editor"]))

    mutual_pairs = {
        pair for pair, pair_directions in directions.items()
        if len(pair_directions) == 2
    }
    contributions = defaultdict(float)
    mutual_events = []
    for event in events:
        pair = tuple(event["pair"])
        if pair not in mutual_pairs:
            continue
        mutual_events.append(event)
        contributions[pair] += min(edit_counts[pair[0]], edit_counts[pair[1]])

    involved_editors = {editor for pair in mutual_pairs for editor in pair}
    raw_sum = float(sum(contributions.values()))
    if contributions:
        top_pair, top_value = max(
            contributions.items(), key=lambda item: (item[1], item[0])
        )
    else:
        top_pair, top_value = None, 0.0

    censored_sum = raw_sum - float(top_value)
    score = float(len(involved_editors) * censored_sum)
    return {
        "value": score,
        "raw_mutual_revert_sum": raw_sum,
        "censored_mutual_revert_sum": censored_sum,
        "mutually_reverting_editor_count": len(involved_editors),
        "mutual_pair_count": len(mutual_pairs),
        "mutual_revert_count": len(mutual_events),
        "excluded_top_pair": list(top_pair) if top_pair else None,
        "excluded_top_pair_contribution": float(top_value),
        "mutual_pairs": [list(pair) for pair in sorted(mutual_pairs)],
    }


def analyze_reverts(history: list[dict], sampled: list[dict]) -> dict:
    """Return full-history revert evidence aligned to sampled curve points."""
    events = detect_sha1_reverts(history)
    point_statistics = []
    previous_cutoff = -1

    for revision in sampled:
        cutoff = revision["history_index"]
        prefix_events = [
            event for event in events if event["revision_index"] <= cutoff
        ]
        interval_events = [
            event for event in prefix_events
            if previous_cutoff < event["revision_index"] <= cutoff
        ]
        measure = yasseri_m_measure(history[:cutoff + 1], prefix_events)
        current_mutual_pairs = {
            tuple(pair) for pair in measure["mutual_pairs"]
        }
        point_statistics.append({
            "interval_revert_count": len(interval_events),
            "interval_mutual_revert_count": sum(
                tuple(event["pair"]) in current_mutual_pairs
                for event in interval_events
            ),
            "cumulative_revert_count": len(prefix_events),
            "cumulative_yasseri_m": measure["value"],
        })
        previous_cutoff = cutoff

    final_measure = yasseri_m_measure(history, events)
    return {
        "method": "SHA1 identity revert detection",
        "definition": (
            "A revision is a revert when its SHA1 restores an earlier "
            "non-adjacent article state."
        ),
        "total_revert_count": len(events),
        "total_mutual_revert_count": final_measure["mutual_revert_count"],
        "yasseri_m": final_measure,
        "events": events,
        "point_statistics": point_statistics,
    }
