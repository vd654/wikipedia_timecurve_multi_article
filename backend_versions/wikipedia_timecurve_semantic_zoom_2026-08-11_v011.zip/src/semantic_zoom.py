#!/usr/bin/env python3
"""Build an offline label hierarchy and a semantic-zoom Vega timecurve."""

from __future__ import annotations

import argparse
import colorsys
import hashlib
import html
import json
import math
import re
from collections import Counter, defaultdict
from pathlib import Path
from typing import Iterable

from openai import OpenAI
from pydantic import BaseModel, Field

from config import BASE_DIR, article_paths
from revision_keywords import (
    DEFAULT_GIT_DIFF_ALGORITHM,
    diff_opcodes,
    iter_revisions,
    load_api_key,
    select_visualized_revisions,
)


MODEL = "gpt-5.6-terra"
SEMANTIC_ZOOM_SNAPSHOT_ID = "2026-08-11-v011"
LABEL_SYSTEM_PROMPT = """You create concise map labels for a semantic revision trajectory.
Use only the supplied revision-keyword evidence. Never add outside knowledge.
The final visualization is a three-layer level-of-detail pyramid: abstract
cluster topics, narrower chronological sections, and detailed consecutive
revision differences. You are labeling the first two layers; the detailed
revision differences already exist as grounded leaf labels.
Each label is an umbrella concept for its node, not a generic label such as
'changes', 'revision', 'miscellaneous', or a numbered level. Prefer two to five
words. Preserve meaningful names, institutions, places, events, and policies."""


class NodeLabel(BaseModel):
    node_id: str
    label: str = Field(min_length=2, max_length=80)


class NodeLabelBatch(BaseModel):
    labels: list[NodeLabel]


def _normalise_term(value: str) -> str:
    return " ".join(value.strip().split())


def _term_key(value: str) -> str:
    return re.sub(r"[^\w]+", " ", value.casefold()).strip()


def top_terms(keyword_groups: Iterable[Iterable[str]], limit: int = 12) -> list[str]:
    """Return frequent grounded terms while preserving their best spelling."""
    counts: Counter[str] = Counter()
    spelling: dict[str, str] = {}
    for group in keyword_groups:
        seen = set()
        for raw in group:
            term = _normalise_term(raw)
            key = _term_key(term)
            if not key or key in seen:
                continue
            seen.add(key)
            counts[key] += 1
            spelling.setdefault(key, term)
    return [spelling[key] for key, _ in counts.most_common(limit)]


def fallback_label(terms: list[str], default: str) -> str:
    """A grounded deterministic label used when LLM generation is disabled."""
    if not terms:
        return default
    if len(terms) == 1:
        return terms[0]
    first_words = {_term_key(term).split()[0] for term in terms[:3] if _term_key(term)}
    if len(first_words) == 1:
        return terms[0]
    return " · ".join(terms[:2])


def validate_sources(projection: dict, keywords: dict) -> tuple[list[dict], list[dict]]:
    points = projection.get("points")
    pairs = keywords.get("revision_pairs")
    if not isinstance(points, list) or len(points) < 2:
        raise ValueError("Projektionsdatei enthält weniger als zwei Punkte.")
    if not isinstance(pairs, list) or len(pairs) != len(points) - 1:
        raise ValueError("Keyword-Datei muss genau ein Paar pro Trajektorienkante enthalten.")
    for index, pair in enumerate(pairs):
        if (
            str(pair.get("previous_revision_id")) != str(points[index]["revision_id"])
            or str(pair.get("current_revision_id")) != str(points[index + 1]["revision_id"])
        ):
            raise ValueError(f"Keyword-Paar {index + 1} passt nicht zur Projektion.")
    return points, pairs


def chronological_runs(points: list[dict]) -> list[dict]:
    """Return maximal chronological runs of one HDBSCAN cluster."""
    runs = []
    start = 0
    while start < len(points):
        cluster_id = int(points[start]["cluster_id"])
        end = start + 1
        while end < len(points) and int(points[end]["cluster_id"]) == cluster_id:
            end += 1
        runs.append({"cluster_id": cluster_id, "start": start, "end": end})
        start = end
    return runs


def _mean_xy(points: list[dict], indices: Iterable[int]) -> tuple[float, float]:
    selected = [points[index]["mds"] for index in indices]
    return (
        sum(float(item[0]) for item in selected) / len(selected),
        sum(float(item[1]) for item in selected) / len(selected),
    )


def _counts_from_xml(xml_path: Path, points: list[dict]) -> list[tuple[int, int]]:
    """Compute true added/removed word counts with the configured Git word diff."""
    revision_ids = [str(point["revision_id"]) for point in points]
    revisions = list(select_visualized_revisions(
        iter_revisions(xml_path, revision_ids=revision_ids), revision_ids
    ))
    counts = []
    for previous, current in zip(revisions, revisions[1:]):
        old_words = previous["text"].split()
        new_words = current["text"].split()
        opcodes = diff_opcodes(
            old_words, new_words, "git", DEFAULT_GIT_DIFF_ALGORITHM
        )
        removed = sum(i2 - i1 for tag, i1, i2, _, _ in opcodes if tag in {"delete", "replace"})
        added = sum(j2 - j1 for tag, _, _, j1, j2 in opcodes if tag in {"insert", "replace"})
        counts.append((added, removed))
    return counts


def cached_word_counts(
    labels_path: Path,
    projection_path: Path,
    keywords_path: Path,
    pair_count: int,
) -> list[tuple[int, int]] | None:
    """Reuse audited Git counts from an earlier hierarchy build."""
    if not labels_path.exists():
        return None
    payload = json.loads(labels_path.read_text(encoding="utf-8"))
    if (
        Path(payload.get("projection", "")) != projection_path
        or Path(payload.get("revision_keywords", "")) != keywords_path
        or not payload.get("word_counts_are_git_word_diff")
    ):
        return None
    edges = payload.get("hierarchy", {}).get("edges", [])
    if len(edges) != pair_count:
        return None
    result = []
    pattern = re.compile(r"^\+(\d+)/−(\d+) Wörter$")
    for edge in edges:
        match = pattern.match(edge.get("count_text", ""))
        if not match:
            return None
        result.append((int(match.group(1)), int(match.group(2))))
    return result


def build_hierarchy(
    projection: dict,
    keywords: dict,
    word_counts: list[tuple[int, int]] | None = None,
    root_label: str = "Article",
) -> dict:
    """Create root, cluster, chronological-section, and edge label candidates."""
    points, pairs = validate_sources(projection, keywords)
    if word_counts is not None and len(word_counts) != len(pairs):
        raise ValueError("Die Zahl der Wortzählungen passt nicht zu den Paaren.")

    edges = []
    for index, pair in enumerate(pairs):
        previous = points[index]
        current = points[index + 1]
        x = (float(previous["mds"][0]) + float(current["mds"][0])) / 2
        y = (float(previous["mds"][1]) + float(current["mds"][1])) / 2
        terms = top_terms([
            pair.get("focus_keywords", []),
            pair.get("added_keywords", []),
            pair.get("removed_keywords", []),
        ], 6)
        added, removed = word_counts[index] if word_counts else (None, None)
        count_text = f"+{added}/−{removed} Wörter" if added is not None else ""
        # A trajectory edge carries exactly one grounded keyword candidate.
        # The keyword itself may be a short multi-word term such as
        # "UN General Assembly", but multiple candidates are never combined.
        label = terms[0] if terms else ""
        edges.append({
            "node_id": f"edge-{index + 1}",
            "level": "edge",
            "x": x,
            "y": y,
            "label": label,
            "short_label": fallback_label(terms, "Textänderung"),
            "terms": terms,
            "count_text": count_text,
            "added_words": added,
            "removed_words": removed,
            "pair_index": index,
            "previous_revision_id": str(pair["previous_revision_id"]),
            "current_revision_id": str(pair["current_revision_id"]),
            "importance": max(
                float(current.get("semantic_jump_from_previous", 0.0)), 1e-9
            ),
        })

    sections = []
    edge_to_section: dict[int, str] = {}
    for run_number, run in enumerate(chronological_runs(points), start=1):
        # A section needs at least two edges. Shorter runs remain leaf-only.
        edge_indices = list(range(run["start"], run["end"] - 1))
        if len(edge_indices) < 2:
            continue
        node_id = f"section-{run_number}"
        x, y = _mean_xy(points, range(run["start"], run["end"]))
        terms = top_terms((edges[index]["terms"] for index in edge_indices), 12)
        if not terms:
            continue
        sections.append({
            "node_id": node_id,
            "level": "section",
            "cluster_id": run["cluster_id"],
            "x": x,
            "y": y,
            "label": fallback_label(terms, "Lokale Entwicklung"),
            "terms": terms,
            "edge_indices": edge_indices,
            "revision_count": len(edge_indices) + 1,
            "importance": len(edge_indices) * (
                1 + sum(edges[index]["importance"] for index in edge_indices)
            ),
        })
        for index in edge_indices:
            edge_to_section[index] = node_id

    clusters = []
    clustered_indices: dict[int, list[int]] = defaultdict(list)
    for index, point in enumerate(points):
        cluster_id = int(point["cluster_id"])
        if cluster_id >= 0:
            clustered_indices[cluster_id].append(index)
    for cluster_id, indices in sorted(clustered_indices.items()):
        node_id = f"cluster-{cluster_id}"
        related_edges = [
            index for index in range(len(edges))
            if int(points[index + 1]["cluster_id"]) == cluster_id
        ]
        x, y = _mean_xy(points, indices)
        terms = top_terms((edges[index]["terms"] for index in related_edges), 16)
        clusters.append({
            "node_id": node_id,
            "level": "cluster",
            "cluster_id": cluster_id,
            "hdbscan_label": f"Cluster {cluster_id + 1}",
            "x": x,
            "y": y,
            "label": fallback_label(terms, ""),
            "terms": terms,
            "point_indices": indices,
            "revision_count": len(indices),
            "importance": len(indices) * (
                1 + sum(edges[index]["importance"] for index in related_edges)
            ),
        })

    for index, edge in enumerate(edges):
        edge["parent_id"] = edge_to_section.get(index)
        if edge["parent_id"] is None:
            cluster_id = int(points[index + 1]["cluster_id"])
            edge["parent_id"] = f"cluster-{cluster_id}" if cluster_id >= 0 else None
    for section in sections:
        cluster_id = int(section["cluster_id"])
        section["parent_id"] = f"cluster-{cluster_id}" if cluster_id >= 0 else "root"

    root_x, root_y = _mean_xy(points, range(len(points)))
    roots = [{
        "node_id": "root",
        "level": "root",
        "x": root_x,
        "y": root_y,
        "label": root_label,
        "terms": [root_label],
        "revision_count": len(points),
        "importance": float(len(points)),
        "parent_id": None,
    }]
    for cluster in clusters:
        cluster["parent_id"] = "root"
    for edge in edges:
        if edge["parent_id"] is None:
            edge["parent_id"] = "root"

    return {"roots": roots, "clusters": clusters, "sections": sections, "edges": edges}


def generate_labels(
    client: OpenAI,
    model: str,
    nodes: list[dict],
    batch_size: int = 16,
) -> dict[str, str]:
    """Generate hierarchy labels in offline batches and validate node IDs."""
    generated: dict[str, str] = {}
    for start in range(0, len(nodes), batch_size):
        batch = nodes[start:start + batch_size]
        evidence = [
            {
                "node_id": node["node_id"],
                "kind": node["level"],
                "revision_count": node.get("revision_count"),
                "grounded_keywords": node["terms"],
            }
            for node in batch
        ]
        prompt = (
            "Create one umbrella label for every node below. More abstract cluster labels "
            "must summarize the supplied evidence; section labels should be narrower. "
            "Return every node_id exactly once.\n\n"
            + json.dumps(evidence, ensure_ascii=False, indent=2)
        )
        response = client.responses.parse(
            model=model,
            store=False,
            input=[
                {"role": "system", "content": LABEL_SYSTEM_PROMPT},
                {"role": "user", "content": prompt},
            ],
            text_format=NodeLabelBatch,
        )
        if response.output_parsed is None:
            raise RuntimeError(f"Keine auswertbaren Hierarchielabels: {response.output_text}")
        expected = {node["node_id"] for node in batch}
        actual = {item.node_id for item in response.output_parsed.labels}
        if actual != expected:
            raise RuntimeError(
                "LLM-Label-IDs stimmen nicht mit dem Batch überein: "
                f"fehlend={sorted(expected - actual)}, extra={sorted(actual - expected)}"
            )
        for item in response.output_parsed.labels:
            generated[item.node_id] = _normalise_term(item.label)
    return generated


def cached_llm_labels(
    labels_path: Path,
    projection_path: Path,
    keywords_path: Path,
    model: str,
) -> dict[str, str]:
    """Reuse already generated offline labels for unchanged hierarchy nodes."""
    if not labels_path.exists():
        return {}
    payload = json.loads(labels_path.read_text(encoding="utf-8"))
    if (
        Path(payload.get("projection", "")) != projection_path
        or Path(payload.get("revision_keywords", "")) != keywords_path
        or payload.get("model") != model
        or payload.get("label_system_prompt") != LABEL_SYSTEM_PROMPT
    ):
        return {}
    result = {}
    hierarchy = payload.get("hierarchy", {})
    for level in ("clusters", "sections"):
        for node in hierarchy.get(level, []):
            if node.get("node_id") and node.get("label"):
                result[node["node_id"]] = node["label"]
    return result


def _finite_extent(values: list[float]) -> list[float]:
    low, high = min(values), max(values)
    padding = max((high - low) * 0.06, 1e-9)
    return [low - padding, high + padding]


def cluster_colour(cluster_id: int) -> str:
    """Return the stable HDBSCAN colour used by the original timecurve."""
    if cluster_id == -1:
        return "#8a8a8a"
    hue = (cluster_id * 0.61803398875) % 1.0
    lightness = 0.48 if cluster_id % 2 == 0 else 0.60
    red, green, blue = colorsys.hls_to_rgb(hue, lightness, 0.72)
    return f"#{round(red * 255):02x}{round(green * 255):02x}{round(blue * 255):02x}"


def build_vega_spec(article: str, projection: dict, hierarchy: dict) -> dict:
    points = projection["points"]
    point_rows = [
        {
            "x": float(point["mds"][0]),
            "y": float(point["mds"][1]),
            "order": int(point["revision_index"]),
            "revision_id": str(point["revision_id"]),
            "timestamp": point["timestamp"],
            "author": point["author"],
            "words": int(point["clean_word_count"]),
            "cluster_id": int(point["cluster_id"]),
            "cluster_label": (
                "Noise"
                if int(point["cluster_id"]) == -1
                else f"Cluster {int(point['cluster_id']) + 1}"
            ),
            "cluster_probability": float(point.get("cluster_probability", 0.0)),
            "semantic_jump": float(point["semantic_jump_from_previous"]),
        }
        for point in points
    ]
    edge_rows = []
    for index, edge in enumerate(hierarchy["edges"]):
        a, b = point_rows[index], point_rows[index + 1]
        semantic_jump = b["semantic_jump"]
        edge_rows.append({
            "edge": index,
            "x": a["x"],
            "y": a["y"],
            "x2": b["x"],
            "y2": b["y"],
            "label": edge["label"],
            "previous_revision_id": edge["previous_revision_id"],
            "current_revision_id": edge["current_revision_id"],
            "semantic_jump": semantic_jump,
        })

    xs = [row["x"] for row in point_rows]
    ys = [row["y"] for row in point_rows]
    x_extent = _finite_extent(xs)
    y_extent = _finite_extent(ys)
    cluster_ids = sorted({row["cluster_id"] for row in point_rows})
    detail_labels = [
        node for node in (
            hierarchy["clusters"] + hierarchy["sections"] + hierarchy["edges"]
        ) if node["label"]
    ]
    label_rows = [
        {
            "node_id": node["node_id"],
            "level": node["level"],
            "x": node["x"],
            "y": node["y"],
            "label": node["label"],
            "display_label": node["label"],
            "importance": node["importance"],
            "revision_count": node.get("revision_count"),
        }
        for node in detail_labels
    ]
    root_row = {
        "x": hierarchy["roots"][0]["x"],
        "y": hierarchy["roots"][0]["y"],
        "label": hierarchy["roots"][0]["label"],
        "revision_count": hierarchy["roots"][0]["revision_count"],
    }
    return {
        "$schema": "https://vega.github.io/schema/vega/v5.json",
        "description": f"Semantic zoom revision timecurve for {article}",
        "autosize": "none",
        "width": 1180,
        "height": 760,
        "padding": {"top": 18, "left": 28, "right": 28, "bottom": 28},
        "background": "#fbfaf7",
        "signals": [
            {"name": "xext", "value": x_extent},
            {"name": "yext", "value": y_extent},
            {"name": "xdom", "update": "xext", "on": [
                {"events": {"signal": "delta"}, "update": "[xcur[0] + span(xcur) * delta[0] / width, xcur[1] + span(xcur) * delta[0] / width]"},
                {"events": {"signal": "zoom"}, "update": "[anchor[0] + (xdom[0] - anchor[0]) * zoom, anchor[0] + (xdom[1] - anchor[0]) * zoom]"},
                {"events": "dblclick", "update": "xext"},
            ]},
            {"name": "ydom", "update": "yext", "on": [
                {"events": {"signal": "delta"}, "update": "[ycur[0] + span(ycur) * delta[1] / height, ycur[1] + span(ycur) * delta[1] / height]"},
                {"events": {"signal": "zoom"}, "update": "[anchor[1] + (ydom[0] - anchor[1]) * zoom, anchor[1] + (ydom[1] - anchor[1]) * zoom]"},
                {"events": "dblclick", "update": "yext"},
            ]},
            {"name": "down", "value": None, "on": [
                {"events": "pointerdown", "update": "xy()"},
                {"events": "window:pointerup", "update": "null"},
            ]},
            {"name": "xcur", "value": None, "on": [
                {"events": "pointerdown", "update": "slice(xdom)"},
            ]},
            {"name": "ycur", "value": None, "on": [
                {"events": "pointerdown", "update": "slice(ydom)"},
            ]},
            {"name": "delta", "value": [0, 0], "on": [
                {"events": [{"source": "window", "type": "pointermove", "consume": True, "between": [{"type": "pointerdown"}, {"source": "window", "type": "pointerup"}]}],
                 "update": "down ? [down[0]-x(), y()-down[1]] : [0,0]"},
            ]},
            {"name": "anchor", "value": [0, 0], "on": [
                {"events": "wheel", "update": "[invert('xscale', x()), invert('yscale', y())]"},
            ]},
            {"name": "zoom", "value": 1, "on": [
                {"events": "wheel!", "force": True, "update": "min(pow(1.001, event.deltaY * pow(16, event.deltaMode)), max(1, span(xext)/span(xdom)))"},
            ]},
            {"name": "zooming", "value": False, "on": [
                {"events": "wheel", "update": "true"},
                {"events": {"type": "wheel", "debounce": 140}, "update": "false"},
            ]},
            {"name": "zoomLevel", "update": "max(0, log((xext[1]-xext[0])/(xdom[1]-xdom[0]))/log(2))"},
            {"name": "semanticLayer", "update": "zoomLevel < 0.7 ? 'root' : zoomLevel < 2.4 ? 'cluster' : zoomLevel < 4.15 ? 'section' : 'edge'"},
            {"name": "rootOpacity", "update": "semanticLayer==='root' ? 1 : 0"},
            {"name": "clusterOpacity", "update": "semanticLayer==='cluster' ? 1 : 0"},
            {"name": "sectionOpacity", "update": "semanticLayer==='section' ? 1 : 0"},
            {"name": "edgeOpacity", "update": "semanticLayer==='edge' ? 1 : 0"},
        ],
        "data": [
            {"name": "points", "values": point_rows},
            {"name": "edges", "values": edge_rows},
            {"name": "rootNode", "values": [root_row]},
            {"name": "labels", "values": label_rows},
            {"name": "visibleParentLabels", "source": "labels", "transform": [
                {"type": "filter", "expr": "!zooming && !down"},
                {"type": "filter", "expr": "(datum.level==='cluster' && clusterOpacity>0.03) || (datum.level==='section' && sectionOpacity>0.03)"},
                {"type": "filter", "expr": "datum.x >= min(xdom[0], xdom[1]) && datum.x <= max(xdom[0], xdom[1]) && datum.y >= min(ydom[0], ydom[1]) && datum.y <= max(ydom[0], ydom[1])"},
                {"type": "formula", "as": "labelOpacity", "expr": "datum.level==='cluster' ? clusterOpacity : sectionOpacity"},
                {"type": "formula", "as": "placementOrder", "expr": "-datum.importance"},
                {"type": "window", "groupby": ["level"], "sort": {"field": "importance", "order": "descending"}, "ops": ["row_number"], "fields": [None], "as": ["levelRank"]},
                {"type": "filter", "expr": "(datum.level==='cluster' && datum.levelRank<=(width<500?5:10)) || (datum.level==='section' && datum.levelRank<=(width<500?10:22))"},
                {"type": "collect", "sort": {"field": "placementOrder", "order": "ascending"}},
            ]},
            {"name": "visibleEdgeLabels", "source": "labels", "transform": [
                {"type": "filter", "expr": "!zooming && !down && datum.level==='edge' && edgeOpacity>0.03"},
                {"type": "filter", "expr": "datum.x >= min(xdom[0], xdom[1]) && datum.x <= max(xdom[0], xdom[1]) && datum.y >= min(ydom[0], ydom[1]) && datum.y <= max(ydom[0], ydom[1])"},
                {"type": "window", "sort": {"field": "importance", "order": "descending"}, "ops": ["row_number"], "fields": [None], "as": ["edgeRank"]},
                {"type": "filter", "expr": "datum.edgeRank<=(width<500?12:35)"},
            ]},
        ],
        "scales": [
            {"name": "xscale", "zero": False, "domain": {"signal": "xdom"}, "range": "width"},
            {"name": "yscale", "zero": False, "domain": {"signal": "ydom"}, "range": "height"},
            {"name": "pointSize", "type": "sqrt", "domain": {"data": "points", "field": "words"}, "range": [18, 105]},
            {"name": "clusterColor", "type": "ordinal", "domain": cluster_ids, "range": [cluster_colour(cluster_id) for cluster_id in cluster_ids]},
            {"name": "jumpWidth", "type": "sqrt", "domain": {"data": "edges", "field": "semantic_jump"}, "range": [0.7, 4.2], "zero": True},
        ],
        "marks": [
            {
                "name": "trajectory",
                "type": "rule",
                "from": {"data": "edges"},
                "encode": {"update": {
                    "x": {"scale": "xscale", "field": "x"},
                    "y": {"scale": "yscale", "field": "y"},
                    "x2": {"scale": "xscale", "field": "x2"},
                    "y2": {"scale": "yscale", "field": "y2"},
                    "stroke": {"value": "#72806f"},
                    "strokeOpacity": {"signal": "0.28 + 0.2*min(zoomLevel/4,1)"},
                    "strokeWidth": {"scale": "jumpWidth", "field": "semantic_jump"},
                    "tooltip": {"signal": "{'Änderung': datum.label, 'Von Revision': datum.previous_revision_id, 'Zu Revision': datum.current_revision_id, 'Semantischer Sprung': format(datum.semantic_jump, '.4f')}"},
                }}
            },
            {
                "name": "revisionPoints", "type": "symbol", "from": {"data": "points"},
                "encode": {"enter": {
                    "tooltip": {"signal": "{'Revision': datum.revision_id, 'Zeit': datum.timestamp, 'Autor': datum.author, 'Wörter': datum.words, 'HDBSCAN': datum.cluster_label, 'Cluster-Wahrscheinlichkeit': format(datum.cluster_probability, '.3f')}"}
                }, "update": {
                    "x": {"scale": "xscale", "field": "x"}, "y": {"scale": "yscale", "field": "y"},
                    "size": {"scale": "pointSize", "field": "words"},
                    "fill": {"scale": "clusterColor", "field": "cluster_id"},
                    "fillOpacity": {"signal": "0.62 + 0.24*min(zoomLevel/4,1)"},
                    "stroke": {"value": "#fbfaf7"}, "strokeWidth": {"value": 0.8},
                }}
            },
            {
                "name": "semanticLabelAnchors", "type": "symbol", "from": {"data": "visibleParentLabels"},
                "encode": {"update": {
                    "x": {"scale": "xscale", "field": "x"}, "y": {"scale": "yscale", "field": "y"},
                    "size": {"value": 1},
                    "fillOpacity": {"value": 0}, "strokeOpacity": {"value": 0}
                }}
            },
            {
                "name": "semanticLabels", "type": "text", "from": {"data": "semanticLabelAnchors"},
                "transform": [
                    {"type": "label", "anchor": ["top"], "offset": [10, 16, 22], "padding": 2, "avoidBaseMark": False, "sort": {"field": "datum.placementOrder"}, "size": {"signal": "[width, height]"}},
                ],
                "encode": {"enter": {
                    "text": {"field": "datum.display_label"}
                }, "update": {
                    "opacity": {"field": "datum.labelOpacity"},
                    "fill": {"value": "#151915"},
                    "font": {"value": "Inter, Arial, sans-serif"},
                    "fontSize": {"signal": "datum.datum.level==='cluster' ? 18 : 14"},
                    "fontWeight": {"signal": "datum.datum.level==='cluster' ? 600 : 500"},
                }}
            },
            {
                "name": "edgeLabels", "type": "text", "from": {"data": "visibleEdgeLabels"},
                "encode": {"enter": {
                    "text": {"field": "label"}, "align": {"value": "center"},
                    "baseline": {"value": "middle"},
                    "font": {"value": "Inter, Arial, sans-serif"},
                    "fontSize": {"value": 11}, "fontWeight": {"value": 400},
                    "limit": {"value": 280},
                    "fill": {"value": "#4f5750"},
                }, "update": {
                    "x": {"scale": "xscale", "field": "x"},
                    "y": {"scale": "yscale", "field": "y"},
                    "opacity": {"signal": "edgeOpacity"},
                }}
            },
            {
                "name": "rootLabel", "type": "text", "from": {"data": "rootNode"},
                "encode": {"enter": {
                    "text": {"field": "label"}, "align": {"value": "center"},
                    "baseline": {"value": "middle"},
                    "font": {"value": "Inter, Arial, sans-serif"},
                    "fontSize": {"value": 28}, "fontWeight": {"value": 600},
                    "fill": {"value": "#151915"}
                }, "update": {
                    "x": {"scale": "xscale", "field": "x"},
                    "y": {"scale": "yscale", "field": "y"},
                    "opacity": {"signal": "rootOpacity"},
                }}
            },
        ],
    }


def render_html(article: str, spec: dict) -> str:
    encoded = json.dumps(spec, ensure_ascii=False, separators=(",", ":"))
    return f"""<!doctype html>
<html lang="de"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Semantische Zoom-Timecurve – {html.escape(article)}</title>
<script src="https://cdn.jsdelivr.net/npm/vega@5"></script>
<script src="https://cdn.jsdelivr.net/npm/vega-tooltip@0.35.2/build/vega-tooltip.min.js"></script>
<style>
html,body{{height:100%;margin:0;background:#fbfaf7;color:#151915;font-family:Inter,Arial,sans-serif}}
#app{{height:100%;display:flex;flex-direction:column;overflow:hidden}}
#topbar{{display:flex;align-items:baseline;justify-content:space-between;gap:20px;padding:14px 20px 8px}}
#topbar h1{{font-size:20px;line-height:1.2;font-weight:600;margin:0}}
#zoom-help{{font-size:11px;color:#687068;white-space:nowrap}}
#vis{{flex:1;min-width:0;min-height:0}}canvas{{cursor:grab}}canvas:active{{cursor:grabbing}}
@media(max-width:720px){{#topbar{{align-items:flex-start;flex-direction:column;gap:4px}}#zoom-help{{white-space:normal}}}}
</style></head><body><main id="app">
<header id="topbar"><h1>Semantische Revisions-Timecurve – {html.escape(article)}</h1>
<div id="zoom-help"><span id="zoom-status">Zoom 1.0×</span> · Scrollen zum Zoomen, Ziehen zum Verschieben, Doppelklick zum Zurücksetzen</div></header>
<div id="vis" role="img" aria-label="Interaktive semantische Revisions-Timecurve"></div>
</main>
<script>
const spec={encoded};
const handler=new vegaTooltip.Handler({{theme:'light'}});
const vis=document.getElementById('vis');
const zoomStatus=document.getElementById('zoom-status');
const view=new vega.View(vega.parse(spec),{{renderer:'canvas',hover:true}})
  .initialize(vis).tooltip(handler.call);
view.addSignalListener('zoomLevel',(_,value)=>{{
  zoomStatus.textContent=`Zoom ${{Math.pow(2,value).toFixed(1)}}×`;
}});
let resizeFrame=0;
let lastWidth=0;
let lastHeight=0;
function resizeView(){{
  cancelAnimationFrame(resizeFrame);
  resizeFrame=requestAnimationFrame(()=>{{
    const width=Math.max(320,vis.clientWidth-56);
    const height=Math.max(420,vis.clientHeight-46);
    if(width===lastWidth&&height===lastHeight)return;
    lastWidth=width;lastHeight=height;
    view.width(width).height(height).runAsync();
  }});
}}
new ResizeObserver(resizeView).observe(vis);
resizeView();
</script></body></html>"""


def source_sha256(paths: Iterable[Path]) -> str:
    digest = hashlib.sha256()
    for path in sorted(paths, key=lambda item: item.as_posix()):
        digest.update(path.name.encode())
        digest.update(b"\0")
        digest.update(path.read_bytes())
        digest.update(b"\0")
    return digest.hexdigest()


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Build semantic-zoom hierarchy and Vega timecurve.")
    parser.add_argument("--projection", type=Path, required=True)
    parser.add_argument("--keywords", type=Path, required=True)
    parser.add_argument("--article", required=True)
    parser.add_argument("--xml", type=Path)
    parser.add_argument("--model", default=MODEL)
    parser.add_argument("--no-llm", action="store_true", help="Keep deterministic grounded fallback labels.")
    parser.add_argument("--skip-word-counts", action="store_true")
    parser.add_argument("--labels-output", type=Path)
    parser.add_argument("--html-output", type=Path)
    return parser.parse_args()


def main() -> int:
    args = parse_args()
    projection_path = args.projection.expanduser().resolve()
    keywords_path = args.keywords.expanduser().resolve()
    projection = json.loads(projection_path.read_text(encoding="utf-8"))
    keywords = json.loads(keywords_path.read_text(encoding="utf-8"))
    points, pairs = validate_sources(projection, keywords)

    labels_output = args.labels_output or projection_path.with_name(
        projection_path.stem.removesuffix("_projection") + "_semantic_zoom_labels.json"
    )
    html_output = args.html_output or projection_path.with_name(
        projection_path.stem.removesuffix("_projection") + "_semantic_zoom.html"
    )

    xml_path = args.xml
    if xml_path is None and not args.skip_word_counts:
        xml_path = Path(article_paths(args.article)["xml_path"])
    word_counts = None
    if not args.skip_word_counts:
        word_counts = cached_word_counts(
            labels_output, projection_path, keywords_path, len(pairs)
        ) or _counts_from_xml(xml_path, points)
    hierarchy = build_hierarchy(
        projection, keywords, word_counts, root_label=args.article
    )

    llm_labels = {}
    if not args.no_llm:
        nodes = [
            node for node in hierarchy["clusters"] + hierarchy["sections"]
            if node["terms"]
        ]
        llm_labels = cached_llm_labels(
            labels_output, projection_path, keywords_path, args.model
        )
        missing = [node for node in nodes if node["node_id"] not in llm_labels]
        if missing:
            client = OpenAI(api_key=load_api_key(Path(BASE_DIR) / ".env"))
            llm_labels.update(generate_labels(client, args.model, missing))
        for level in ("clusters", "sections"):
            for node in hierarchy[level]:
                node["label"] = llm_labels[node["node_id"]] if node["terms"] else ""

    payload = {
        "article": args.article,
        "projection": str(projection_path),
        "revision_keywords": str(keywords_path),
        "model": None if args.no_llm else args.model,
        "labels_generated_offline": True,
        "interactive_llm_calls": False,
        "pipeline_snapshot_id": SEMANTIC_ZOOM_SNAPSHOT_ID,
        "source_sha256": source_sha256([Path(__file__), projection_path, keywords_path]),
        "label_system_prompt": None if args.no_llm else LABEL_SYSTEM_PROMPT,
        "word_counts_are_git_word_diff": word_counts is not None,
        "hierarchy": hierarchy,
    }
    labels_output.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")
    html_output.write_text(render_html(args.article, build_vega_spec(args.article, projection, hierarchy)), encoding="utf-8")
    print(f"Labelhierarchie: {labels_output}")
    print(f"Semantische Zoom-Timecurve: {html_output}")
    print(f"Cluster/Abschnitte/Kanten: {len(hierarchy['clusters'])}/{len(hierarchy['sections'])}/{len(hierarchy['edges'])}")
    return 0


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except (FileNotFoundError, ValueError, RuntimeError, UnicodeError) as error:
        print(f"[FEHLER] {error}")
        raise SystemExit(1) from error
